<?php
include ('config.php');
if (!$_FILES["uploadingfile"]["tmp_name"]) {//No file chosen
    echo "ERROR: Please browse for a file before clicking the upload button.";
    exit();
} else {
    $extension = pathinfo($_FILES['uploadingfile']['name'], PATHINFO_EXTENSION);
    if ((($_FILES["uploadingfile"]["type"] == "video/mp4")) && $extension == 'mp4') {
        //Directory to put file into
         $folderPath = "/uploads/";
        
        //File name
        $original_file_name = $_FILES["uploadingfile"]["name"];
        $size_raw = $_FILES["uploadingfile"]["size"];//File size in bytes
        $size_as_mb = number_format(($size_raw / 1048576), 2);//Convert bytes to Megabytes
        $video_ex = pathinfo($original_file_name, PATHINFO_EXTENSION);
         //  echo $video_ex;
        $video_ex_lc = strtolower($video_ex);
        $new_video_name = uniqid("video",true). '.' .$video_ex_lc;
        
        $withoutExt = preg_replace('/\\.[^.\\s]{3,4}$/', '', $original_file_name);    
             // insert query
            $n=15;
            function getName($n) {
                $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
                $randomString = '';
                for ($i = 0; $i < $n; $i++) {
                    $index = rand(0, strlen($characters) - 1);
                    $randomString .= $characters[$index];
                }
                return $randomString;
            }
            
            $video_id=getName($n);
            $upload_date = date('Y-m-d');

        $sql = "insert into user_video(video_url,video_id,video_name,upload_date) values
        ('$new_video_name','$video_id','$withoutExt','$upload_date')";
         $query=mysqli_query($conn,$sql);
         
         if (move_uploaded_file($_FILES["uploadingfile"]["tmp_name"], "$folderPath" . $new_video_name . "")) {
            //Move file
            // echo "$video_id";
            echo "Video Uploaded Successfully.......";
        
        }
    } else {
        echo "File is not a MP4";
        exit;
    }
}
 
 ?>