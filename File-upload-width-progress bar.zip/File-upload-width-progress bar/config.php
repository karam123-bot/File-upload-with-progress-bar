<?php

$conn = mysqli_connect('localhost', 'root','');// hostname , userid
mysqli_select_db($conn, ''); // variable name  , db name
if(!$conn)
{
    echo "connection failed";
}
else
{
    // echo "connection ok";
}



?>